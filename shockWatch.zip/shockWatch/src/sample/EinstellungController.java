package sample;

import java.util.Optional;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Button;

import javafx.scene.input.MouseEvent;
import javafx.scene.input.ZoomEvent;


public class EinstellungController {
	int number = 0;
@FXML
Button Plus;
@FXML
Button Minus;
@FXML
	Label Zahl;





public void setNumber(int num) {

	this.number = num;
}
	public int getNumber(){
		Zahl.setText(""+ number);
		return this.number;


	}



	public void counterPlus(MouseEvent mouseEvent) {
		if (number >= 0 && number < 10) {

			number++;
			if (number == 5) {
				Alert alert = new Alert(Alert.AlertType.WARNING);
				alert.setTitle("High Voltage");

				alert.setContentText("Kann gefährlich werden");


				Optional<ButtonType> result = alert.showAndWait();
				if (result.get() == ButtonType.OK) {


					getNumber();
				}

			}


			getNumber();
		}

		getNumber();
	}

	public void counterMinus(MouseEvent mouseEvent) {
		if (number > 0 && number <=10) {
		number--;

			getNumber();
	}

		getNumber();
	}




















}